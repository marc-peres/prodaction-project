import React from 'react';

const jestEmptyComponent = function () {
    return <div />;
};

export default jestEmptyComponent;
